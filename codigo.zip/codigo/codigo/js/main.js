


var list = JSON.parse(localStorage.getItem('list') || '[]')
var nav = document.querySelectorAll('.nav li')
var show_itens = document.querySelector('.tareas-ul')



nav.forEach((e)=>{
    e.addEventListener('click',(el)=>{
        
        var teste = document.querySelectorAll('.nav li')
        teste.forEach((i)=>{
            i.classList.remove('active')
        })
        el.target.classList.add('active')
        if(el.target.classList.contains('completed')){
           
            show_itens.querySelectorAll('li').forEach((lists) => {
                lists.classList.add('list_completed')
                lists.classList.remove('list_all')
                lists.classList.remove('list_actived')
            })
            if(list.length>0){
                show_itens.querySelectorAll('li').forEach((lists) => {
                    if (lists.classList.contains('actived')){
                        document.querySelector('.removeAll').classList.remove('remove_hide')
                    }
                })
            }

            document.querySelector('.agregar').classList.remove('show_agregar')
            show_itens.querySelectorAll('li .del').forEach((del)=>{
                del.classList.remove('hide_btn_del')
            })
        } else if (el.target.classList.contains('actived')) {
            
            show_itens.querySelectorAll('li').forEach((lists)=>{
                lists.classList.add('list_actived')
                lists.classList.remove('list_completed')
                lists.classList.remove('list_all')
            })
            document.querySelector('.removeAll').classList.add('remove_hide')

            document.querySelector('.agregar').classList.add('show_agregar')
            show_itens.querySelectorAll('li .del').forEach((del) => {
                del.classList.add('hide_btn_del')
            })
        }else if (el.target.classList.contains('all')){
            document.querySelector('.removeAll').classList.add('remove_hide')
            
            show_itens.querySelectorAll('li').forEach((lists) => {
                lists.classList.add('list_all')
                lists.classList.remove('list_completed')
                lists.classList.remove('list_actived')
            })

            document.querySelector('.agregar').classList.add('show_agregar')
            show_itens.querySelectorAll('li .del').forEach((del) => {
                del.classList.add('hide_btn_del')
            })
        }
        
           
            var list_actived = show_itens.querySelectorAll('li')
          
            list_actived.forEach((active)=>{
                if (el.target.classList.contains('actived')){

                   
                    if (active.classList.contains('actived')){
                        active.classList.add('actived_hide')
                        
                    }else{
                        active.classList.remove('actived_hide')
                    }

                }else{
                    active.classList.remove('actived_hide')
                }

                if (el.target.classList.contains('completed')) {
                    if (active.classList.contains('actived')) {
                        active.classList.remove('actived_hide')
                    } else {
                        active.classList.add('actived_hide')
                    }

                }
            })

          
        
    })
})







var btn = document.querySelector('.boton-class')
var input = document.querySelector('.barra')
btn.addEventListener('click',(e)=>{
    var value = input.value.trim()
    if (value != ""){

        var filter = list.find(e=> e.name == value)
        console.log(filter)
        if (filter == undefined){
            

            var data = {
                "name": value,
                "status": "inactived"
            }

            list = [...list, data]
            localStorage.setItem('list', JSON.stringify(list))

            showData()
            document.querySelector('.barra').value = ""
        }else{
            alert(`${value} já existe, digite um outro nome.`)
            document.querySelector('.barra').value = ""
        }
        

    }else{
        alert('Digite um nome')
    }
})





function showData() {
    var cl ='list_all'
    var itens = JSON.parse(localStorage.getItem('list'));
    var template = '';
    itens.forEach((e) => {
        template += `
      <li ${e.status == 'actived' ? `class=${e.status}` : `class=${e.status}`}>
        <div class="list_btn">
          <input type="radio" name="" value="${e.name}" id="${e.name}" ${e.status == 'actived' ? 'checked' : ''
            }>
           <label for="${e.name}">${e.name}</label>
        </div>
        <div class="del hide_btn_del" data-name="${e.name}">
           <i class="fas fa-trash" data-name="${e.name}"></i>
        </div>
      </li>
    `;
    });
    show_itens.innerHTML = template;
   

    var lists_actived = show_itens.querySelectorAll('.inactived .list_btn input');
   

    lists_actived.forEach((e) => {
        e.addEventListener('click', (el) => {
            var renameObject = list.find(function (object) {
                return object.name === el.target.value;
            });

            if (renameObject) {
                renameObject.status = 'actived';
                localStorage.setItem('list', JSON.stringify(list));
                showData();
            }
           
        });
    });

    var lists_del = show_itens.querySelectorAll('li .del');
   
    lists_del.forEach((e) => {
        e.addEventListener('click', (el) => {
            var getName = el.target.getAttribute('data-name')
           
            var objetoRemover = { name: getName };

             list = list.filter(function (objeto) {
                return objeto.name !== objetoRemover.name;
            });

            

           localStorage.setItem('list', JSON.stringify(list));
           showData();
            show_itens.querySelectorAll('li .del').forEach((del) => {
                del.classList.remove('hide_btn_del')
            })
            if (list.length == 0) {
                document.querySelector('.removeAll').classList.remove('remove_hide')
            }
            
        });
    });

    document.querySelector('.removeAll').addEventListener('click',()=>{
        list=[]
        localStorage.setItem('list', JSON.stringify(list));
        showData();
    })




}

showData();



